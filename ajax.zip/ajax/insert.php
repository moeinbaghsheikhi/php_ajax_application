<?php
include 'db.php';
$result = $conn->prepare("INSERT INTO user SET username=? , password=?");
$result->bindValue(1 , $_POST['username']);
$result->bindValue(2 , $_POST['password']);
$result->execute();