<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4"
            crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
            integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <title>Ajax application</title>
</head>
<body>
<div class="container">
    <br>
    <!-- Button trigger modal -->
    <button id="open-modal" type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
        Add new
    </button>
    <br>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add new user</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="post" id="user-form">
                        <input type="hidden" id="user-id">
                        <label for="">Username</label>
                        <input type="text" id="username" class="form-control">
                        <span id="alert-username" class="text-danger" style="font-size: 12px"></span>
                        <br>
                        <label for="">Password</label>
                        <input type="password" id="password" class="form-control">
                        <span id="alert-password" class="text-danger" style="font-size: 12px"></span>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="send-request">Send request</button>
                    <button type="button" class="btn btn-primary" id="update-request" style="display: none">Update</button>
                </div>
            </div>
        </div>
    </div>

    <!--Table-->
    <table class="table">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Username</th>
            <th scope="col">Password</th>
            <th scope="col">Action</th>
        </tr>
        </thead>
        <tbody id="list-users">

        </tbody>
    </table>
    <button id="refres" class="btn btn-info">Refresh</button>
</div>
</body>
<script>
    $(document).ready(function () {

        // Reset form
        $("#open-modal").click(function () {

            // Reset label
            $("#exampleModalLabel").html("Add new user")

            // Reset button
            $("#update-request").hide()
            $("#send-request").show()

            // reset form
            $("#user-form")[0].reset()
            $("#username").val("")
            $("#password").val("")
            $("#user-id").val("")
            $("#username").css('border', '1px solid #ced4da')
            $("#password").css('border', '1px solid #ced4da')
            $("#alert-username").html("")
            $("#alert-password").html("")
        })

        // first Fetch Data
        $.ajax({
            url: 'fetch.php',
            method: 'POST',
            success: function (values) {
                $("#list-users").html(values)
            }
        })

        $("#refres").click(function () {
            $.ajax({
                url: 'fetch.php',
                method: 'POST',
                success: function (values) {
                    $("#list-users").html(values)
                }
            })
        })

        // Validation form
        $("#send-request").click(function () {
            var username = $("#username").val()
            var password = $("#password").val()
            var passlen = password.length;

            // Sending ajax request (insert user)
            if (username != '' && password != '' && passlen > "0" && passlen >= "8"){
                $.ajax({
                    url: 'insert.php',
                    method: 'POST',
                    data: {username:username , password:password},
                    success: function () {
                        swal("Good job!", "Added User succcessfully!", "success");

                        // Fetch request
                        $.ajax({
                            url: 'fetch.php',
                            method: 'POST',
                            success: function (values) {
                                $("#list-users").html(values)
                            }
                        })
                    }
                })
            }

            // Empty fild validate
            if (username == '') {
                $("#username").css('border', '1px solid #df4759')
                $("#alert-username").html("This fild is required")
            }
            if (password == '') {
                $("#password").css('border', '1px solid #df4759')
                $("#alert-password").html("This fild is required")
            }

            // Success validate
            if (username != '') {
                $("#username").css('border', '1px solid #42ba96')
                $("#alert-username").html("")
            }
            if (password != '') {
                if (passlen > "0" && passlen < "8") {
                    $("#password").css('border', '1px solid #df4759')
                    $("#alert-password").html("At least 8 characters")
                } else {
                    $("#password").css('border', '1px solid #42ba96')
                    $("#alert-password").html("")
                }
            }
        })

        // Delete ajax request
        $(document).on('click' , '#delete-user' , function () {
            var id = $(this).val()
            $.ajax({
                url: 'delete.php',
                method: 'POST',
                data: {id:id},
                success: function () {
                    swal("Good job!", "Deleted User succcessfully!", "success");
                    // Fetch request
                    $.ajax({
                        url: 'fetch.php',
                        method: 'POST',
                        success: function (values) {
                            $("#list-users").html(values)
                        }
                    })
                }
            })
        })

        // Update user (Ajax request)
        $(document).on('click' , '#edit-user' , function () {
            var id = $(this).val()

            // reset form
            $("#user-form")[0].reset()
            $("#username").css('border', '1px solid #ced4da')
            $("#password").css('border', '1px solid #ced4da')
            $("#alert-username").html("")
            $("#alert-password").html("")

            $.ajax({
                url: 'fetchRow.php',
                method: 'POST',
                data: {id:id},
                success: function (values) {
                    var data = jQuery.parseJSON(values)
                    $("#user-id").val(data.id)
                    $("#username").val(data.username)
                    $("#password").val(data.password)
                    $("#exampleModalLabel").html("Update user : " + data.username)
                    $("#update-request").show()
                    $("#send-request").hide()
                }
            })
        })

        $("#update-request").click(function () {
            var id = $("#user-id").val()
            var username = $("#username").val()
            var password = $("#password").val()

            $.ajax({
                url: 'update.php',
                method: 'POST',
                data: {id:id , username:username , password:password},
                success: function () {
                    swal("Good job!", "Updated User succcessfully!", "success")
                    // Fetch request
                    $.ajax({
                        url: 'fetch.php',
                        method: 'POST',
                        success: function (values) {
                            $("#list-users").html(values)
                        }
                    })
                }
            })
        })

    })
</script>
</html>